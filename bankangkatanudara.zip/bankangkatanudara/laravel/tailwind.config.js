/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./resources/**/*.blade.php",
    "./resources/**/*.js",
    "./resources/**/*.vue",
    "./app/Livewire/**/*.php",
  ],
  theme: {
    extend: {
      colors: {
        'bau-navy': '#002B49',
        'bau-blue': '#005A9C',
        'bau-gold': '#D4AF37',
        'bau-sky': '#E6F0FA',
      }
    },
  },
  plugins: [],
}
