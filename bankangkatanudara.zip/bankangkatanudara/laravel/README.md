# PT Bank Angkatan Udara (Persero) Tbk - Official Website Lab

Website resmi simulasi **PT Bank Angkatan Udara (Persero) Tbk** dibangun dengan framework **Laravel (PHP 8.0)** dan **Livewire 3**.

## Fitur Utama
- **Profil Perusahaan**: Visi, Misi, Sejarah, dan Struktur Organisasi.
- **Layanan Perbankan**: Tabungan Dirgantara, Deposito Garuda, Kredit Alutsista, & Air-Net Mobile Banking.
- **Berita & Pengumuman**: Update terkini seputar perbankan pertahanan dan keuangan.
- **Komponen Interaktif**: Livewire 3 untuk Form Kontak, Simulasi Deposito, & Live Chat Support.

## Langkah Pengoperasian Lab:
1. Ekstrak repositori ini ke direktori web server Anda (`htdocs` / `www`).
2. Jalankan `composer install` & `npm install`.
3. Salin file `.env.example` ke `.env`.
4. Jalankan `php artisan key:generate`.
5. Buat database `bank_au_db` di MySQL.
6. Jalankan migrasi dan seeder:
   ```bash
   php artisan migrate --seed
   ```
7. Jalankan server lokal:
   ```bash
   php artisan serve
   ```
8. Buka browser di `http://127.0.0.1:8000`.
