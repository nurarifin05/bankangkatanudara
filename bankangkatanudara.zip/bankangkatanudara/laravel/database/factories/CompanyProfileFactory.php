<?php

namespace Database\Factories;

use App\Models\CompanyProfile;
use Illuminate\Database\Eloquent\Factories\Factory;

class CompanyProfileFactory extends Factory
{
    protected $model = CompanyProfile::class;

    public function definition(): array
    {
        return [
            'company_name' => 'PT Bank Angkatan Udara (Persero) Tbk',
            'tagline' => 'Mengangkasa Bersama Melayani Negeri',
            'about' => 'Bank Angkatan Udara adalah lembaga keuangan perbankan terdepan yang berfokus pada pelayanan personel TNI AU, kementerian pertahanan, serta masyarakat umum.',
            'vision' => 'Menjadi bank nasional terpercaya dengan standar keamanan dan teknologi keuangan terbaik.',
            'mission' => 'Memberikan layanan solusi perbankan terintegrasi, mendukung ketahanan finansial nasional, dan mendorong pertumbuhan ekonomi nasional.',
            'email' => 'corporate@bankau.co.id',
            'phone' => '(021) 8088-1234',
            'call_center' => '1500-888',
            'address' => 'Gedung Wisma Dirgantara Lt. 1-8, Jl. M.T. Haryono Cawang, Jakarta Timur',
            'total_assets' => 'Rp 85,4 Triliun',
            'total_branches' => 342,
            'total_clients' => '2.500.000+',
        ];
    }
}
