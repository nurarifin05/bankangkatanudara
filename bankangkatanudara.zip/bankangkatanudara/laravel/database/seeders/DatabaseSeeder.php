<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        User::create([
            'name' => 'Administrator Bank AU',
            'email' => 'admin@bankau.co.id',
            'password' => bcrypt('Password123!'),
            'role' => 'superadmin',
        ]);

        $this->call([
            CompanyProfileSeeder::class,
            ServiceSeeder::class,
            NewsSeeder::class,
        ]);
    }
}
