<?php

namespace Database\Seeders;

use App\Models\News;
use Illuminate\Database\Seeder;

class NewsSeeder extends Seeder
{
    public function run(): void
    {
        News::create([
            'title' => 'Bank Angkatan Udara Catatkan Pertumbuhan Aset 14.5% di Kuartal III 2026',
            'slug' => 'bank-au-catatkan-pertumbuhan-aset-q3-2026',
            'summary' => 'PT Bank Angkatan Udara (Persero) Tbk membukukan kinerja keuangan yang solid berkat transformasi digital Air-Net dan ekspansi Kredit Perumahan.',
            'content' => 'Jakarta - PT Bank Angkatan Udara (Persero) Tbk berhasil mencatatkan peningkatan total aset sebesar 14.5% secara year-on-year (YoY). Direktur Utama Bank AU menyampaikan bahwa pertumbuhan ini dipicu oleh peningkatan penyaluran kredit konsumer serta adopsi layanan digital Air-Net Mobile Banking yang mencapai 1.8 juta pengguna aktif.',
            'category' => 'Laporan Keuangan',
            'author' => 'Tim Sekretariat Perusahaan',
            'published_at' => '2026-10-01 10:00:00',
        ]);

        News::create([
            'title' => 'Peluncuran Fitur Keamanan Siber Terbaru Air-Net dengan Biometrik Liveness',
            'slug' => 'peluncuran-fitur-keamanan-airnet-biometrik',
            'summary' => 'Meningkatkan standar perlindungan transaksi nasabah, Bank AU menerapkan proteksi keamanan berbasis AI dan pengenalan wajah biometrik.',
            'content' => 'Dalam rangka memperkuat ketahanan siber perbankan nasional, Bank Angkatan Udara resmi meluncurkan pembaruan sistem keamanan pada aplikasi Air-Net. Fitur baru ini memanfaatkan teknologi biometrik tingkat tinggi untuk memverifikasi transaksi nasabah secara real-time.',
            'category' => 'Teknologi & Keamanan',
            'author' => 'Divisi Siber & IT Bank AU',
            'published_at' => '2026-09-20 14:30:00',
        ]);

        News::create([
            'title' => 'Program CSR Bank AU Peduli: Bantuan Beasiswa untuk Putra-Putri Personel Paskhas',
            'slug' => 'csr-bank-au-peduli-beasiswa-paskhas',
            'summary' => 'Sebagai bentuk komitmen sosial, Bank AU menyalurkan beasiswa pendidikan total senilai Rp 2.5 Miliar kepada 500 pelajar berprestasi.',
            'content' => 'Penyaluran beasiswa dilakukan secara simbolis di Markas Besar Angkatan Udara. Program ini dirancang untuk mendukung keberlanjutan pendidikan generasi muda penerus bangsa di bidang sains dan teknologi.',
            'category' => 'Corporate Social Responsibility',
            'author' => 'Humas & Tanggung Jawab Sosial',
            'published_at' => '2026-08-15 09:15:00',
        ]);
    }
}
