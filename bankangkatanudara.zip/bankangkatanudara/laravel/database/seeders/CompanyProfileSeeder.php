<?php

namespace Database\Seeders;

use App\Models\CompanyProfile;
use Illuminate\Database\Seeder;

class CompanyProfileSeeder extends Seeder
{
    public function run(): void
    {
        CompanyProfile::create([
            'company_name' => 'PT Bank Angkatan Udara (Persero) Tbk',
            'tagline'      => 'Mengangkasa Bersama Melayani Negeri',
            'about'        => 'PT Bank Angkatan Udara (Persero) Tbk adalah lembaga keuangan milik negara yang hadir memberikan solusi perbankan terpercaya. Didirikan untuk mendukung kemandirian finansial personil pertahanan udara dan masyarakat Indonesia, kami mengintegrasikan teknologi keuangan canggih dengan prinsip tata kelola yang kuat.',
            'vision'       => 'Menjadi Bank BUMN terdepan dalam ketahanan finansial, inovasi perbankan digital, dan pengabdian penuh untuk bangsa.',
            'mission'      => '1. Menyediakan layanan transaksi keuangan cepat, aman, dan mudah diakses.
2. Mendukung program pembiayaan strategis nasional dan personel pertahanan.
3. Mengembangkan ekosistem finansial digital berbasis Artificial Intelligence & Cyber Defense.',
            'email'        => 'sekretariat@bankau.co.id',
            'phone'        => '(021) 8088-1234',
            'call_center'   => '1500-888',
            'address'      => 'Wisma Dirgantara Utama Lt. 1-12, Jl. Komando Air Force No. 1, Halim Perdanakusuma, Jakarta Timur 13610',
            'total_assets' => 'Rp 98,6 Triliun',
            'total_branches' => 420,
            'total_clients' => '3.100.000+',
        ]);
    }
}
