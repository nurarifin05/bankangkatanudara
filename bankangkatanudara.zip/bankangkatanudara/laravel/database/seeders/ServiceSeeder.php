<?php

namespace Database\Seeders;

use App\Models\Service;
use Illuminate\Database\Seeder;

class ServiceSeeder extends Seeder
{
    public function run(): void
    {
        $services = [
            [
                'title' => 'Tabungan Dirgantara Utama',
                'code' => 'TAB-DIRGANTARA',
                'category' => 'Simpanan',
                'description' => 'Tabungan harian dengan bunga kompetitif, bebas biaya administrasi bulanan untuk personel militer, dan fasilitas kartu debit Visa Gold.',
                'icon' => 'credit-card',
                'is_active' => true,
            ],
            [
                'title' => 'Deposito Garuda Prima',
                'code' => 'DEP-GARUDA',
                'category' => 'Investasi',
                'description' => 'Investasi berjangka dengan imbal hasil tinggi hingga 5.75% p.a. Pilihan jangka waktu 1, 3, 6, hingga 12 bulan.',
                'icon' => 'trending-up',
                'is_active' => true,
            ],
            [
                'title' => 'Kredit Pemilikan Rumah (KPR) Air-Home',
                'code' => 'KPR-AIRHOME',
                'category' => 'Pinjaman',
                'description' => 'Solusi kepemilikan hunian idaman dengan suku bunga rendah tetap selama 5 tahun pertama dan tenor hingga 25 tahun.',
                'icon' => 'home',
                'is_active' => true,
            ],
            [
                'title' => 'Air-Net Mobile & Internet Banking',
                'code' => 'DIG-AIRNET',
                'category' => 'Digital Banking',
                'description' => 'Aplikasi perbankan digital generasi terbaru dengan fitur QRIS, transfer antarbank gratis, e-wallet top-up, dan keamanan otentikasi biometrik.',
                'icon' => 'device-phone-mobile',
                'is_active' => true,
            ],
            [
                'title' => 'Kredit Usaha Dirgantara (KUD)',
                'code' => 'KUD-KORPORASI',
                'category' => 'Pinjaman',
                'description' => 'Pembiayaan modal kerja dan investasi bagi UMKM mitra pertahanan dan masyarakat umum dengan bunga subsidi pemerintah.',
                'icon' => 'briefcase',
                'is_active' => true,
            ],
            [
                'title' => 'Bank AU Prioritas',
                'code' => 'PRIORITAS-AU',
                'category' => 'Layanan Khusus',
                'description' => 'Layanan eksklusif manajemen kekayaan (wealth management), konsultasi investasi pribadi, serta fasiltas airport lounge di seluruh Indonesia.',
                'icon' => 'star',
                'is_active' => true,
            ],
        ];

        foreach ($services as $service) {
            Service::create($service);
        }
    }
}
