<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('company_profiles', function (Blueprint $table) {
            $table->id();
            $table->string('company_name');
            $table->string('tagline');
            $table->text('about');
            $table->text('vision');
            $table->text('mission');
            $table->string('email');
            $table->string('phone');
            $table->string('call_center');
            $table->string('address');
            $table->string('total_assets')->default('Rp 85,4 Triliun');
            $table->integer('total_branches')->default(342);
            $table->string('total_clients')->default('2.5 M+');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('company_profiles');
    }
};
