<div class="max-w-4xl mx-auto">
    <div class="text-center mb-10">
        <h2 class="text-3xl font-bold text-white mb-2">Hubungi Customer Service Bank AU</h2>
        <p class="text-slate-300">Silakan kirimkan pertanyaan atau permohonan informasi Anda melalui formulir di bawah ini.</p>
    </div>

    @if($successMessage)
        <div class="bg-emerald-600 text-white p-4 rounded-lg mb-6 text-center font-bold shadow-lg">
            <i class="fas fa-check-circle text-xl mr-2"></i> {{ $successMessage }}
        </div>
    @endif

    <form wire:submit.prevent="submit" class="bg-white/10 backdrop-blur-md p-8 rounded-2xl border border-white/20 grid grid-cols-1 md:grid-cols-2 gap-6 text-slate-800">
        <div>
            <label class="block text-white font-semibold text-sm mb-2">Nama Lengkap *</label>
            <input type="text" wire:model="name" class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-400" placeholder="Masukkan nama Anda">
            @error('name') <span class="text-red-400 text-xs mt-1 block font-semibold">{{ $message }}</span> @enderror
        </div>

        <div>
            <label class="block text-white font-semibold text-sm mb-2">Email Resmi *</label>
            <input type="email" wire:model="email" class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-400" placeholder="nama@domain.com">
            @error('email') <span class="text-red-400 text-xs mt-1 block font-semibold">{{ $message }}</span> @enderror
        </div>

        <div class="md:col-span-2">
            <label class="block text-white font-semibold text-sm mb-2">Subjek Pertanyaan *</label>
            <input type="text" wire:model="subject" class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-400" placeholder="Contoh: Informasi Pembukaan Rekening / Deposito">
            @error('subject') <span class="text-red-400 text-xs mt-1 block font-semibold">{{ $message }}</span> @enderror
        </div>

        <div class="md:col-span-2">
            <label class="block text-white font-semibold text-sm mb-2">Isi Pesan *</label>
            <textarea wire:model="message" rows="4" class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-400" placeholder="Tuliskan rincian pertanyaan Anda..."></textarea>
            @error('message') <span class="text-red-400 text-xs mt-1 block font-semibold">{{ $message }}</span> @enderror
        </div>

        <div class="md:col-span-2 text-center">
            <button type="submit" class="bg-amber-500 hover:bg-amber-600 text-slate-900 font-extrabold px-8 py-3 rounded-lg shadow-lg transition">
                <i class="fas fa-paper-plane mr-2"></i> Kirim Pesan Ke Bank AU
            </button>
        </div>
    </form>
</div>
