<div class="grid grid-cols-1 md:grid-cols-3 gap-8 items-start">
    <div class="bg-slate-100 p-6 rounded-xl border border-slate-200">
        <h3 class="text-xl font-bold text-bauNavy mb-4"><i class="fas fa-building mr-2"></i> Profil Singkat</h3>
        <ul class="space-y-3">
            <li>
                <button wire:click="setTab('tentang')" class="w-full text-left px-4 py-2.5 rounded-lg font-semibold text-sm transition {{ $activeTab === 'tentang' ? 'bg-bauNavy text-white' : 'bg-white text-slate-700 hover:bg-slate-200' }}">
                    Tentang Bank AU
                </button>
            </li>
            <li>
                <button wire:click="setTab('visimisi')" class="w-full text-left px-4 py-2.5 rounded-lg font-semibold text-sm transition {{ $activeTab === 'visimisi' ? 'bg-bauNavy text-white' : 'bg-white text-slate-700 hover:bg-slate-200' }}">
                    Visi & Misi Perusahaan
                </button>
            </li>
            <li>
                <button wire:click="setTab('direksi')" class="w-full text-left px-4 py-2.5 rounded-lg font-semibold text-sm transition {{ $activeTab === 'direksi' ? 'bg-bauNavy text-white' : 'bg-white text-slate-700 hover:bg-slate-200' }}">
                    Jajaran Direksi & Komisaris
                </button>
            </li>
        </ul>
    </div>

    <div class="md:col-span-2 bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
        @if($activeTab === 'tentang')
            <h3 class="text-2xl font-bold text-bauNavy mb-3">{{ $profile->company_name ?? 'PT Bank Angkatan Udara (Persero) Tbk' }}</h3>
            <p class="text-amber-600 font-bold italic mb-4">"{{ $profile->tagline ?? 'Mengangkasa Bersama Melayani Negeri' }}"</p>
            <p class="text-slate-700 leading-relaxed mb-4">
                {{ $profile->about ?? 'Bank Angkatan Udara adalah bank BUMN terkemuka yang melayani transaksi keuangan nasional dengan mengedepankan integritas, keamanan, dan pelayanan prima.' }}
            </p>
            <div class="bg-amber-50 border-l-4 border-amber-500 p-4 text-sm text-slate-800">
                <strong>Lisensi Resmi:</strong> PT Bank Angkatan Udara (Persero) Tbk berizin dan diawasi oleh Otoritas Jasa Keuangan (OJK) serta merupakan peserta penjaminan Lembaga Penjamin Simpanan (LPS).
            </div>
        @elseif($activeTab === 'visimisi')
            <h3 class="text-2xl font-bold text-bauNavy mb-4">Visi & Misi Kami</h3>
            <div class="mb-6">
                <h4 class="font-bold text-amber-600 uppercase text-xs tracking-wider mb-2">VISI</h4>
                <p class="text-slate-700 font-medium">{{ $profile->vision ?? '' }}</p>
            </div>
            <div>
                <h4 class="font-bold text-amber-600 uppercase text-xs tracking-wider mb-2">MISI</h4>
                <div class="text-slate-700 whitespace-pre-line leading-relaxed">{{ $profile->mission ?? '' }}</div>
            </div>
        @elseif($activeTab === 'direksi')
            <h3 class="text-2xl font-bold text-bauNavy mb-4">Jajaran Direksi Utama</h3>
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div class="p-4 border rounded-lg bg-slate-50">
                    <div class="font-bold text-slate-800">Marsekal Muda (Purn.) Hendra Wijaya</div>
                    <div class="text-xs text-amber-600 font-semibold">Direktur Utama</div>
                </div>
                <div class="p-4 border rounded-lg bg-slate-50">
                    <div class="font-bold text-slate-800">Dr. Pratama Kartika, S.E., M.B.A.</div>
                    <div class="text-xs text-amber-600 font-semibold">Direktur Keuangan & Perbankan</div>
                </div>
                <div class="p-4 border rounded-lg bg-slate-50">
                    <div class="font-bold text-slate-800">Ir. Bambang Surya, M.T.</div>
                    <div class="text-xs text-amber-600 font-semibold">Direktur Teknologi Informasi & Siber</div>
                </div>
                <div class="p-4 border rounded-lg bg-slate-50">
                    <div class="font-bold text-slate-800">Siti Rahmawati, S.H.</div>
                    <div class="text-xs text-amber-600 font-semibold">Direktur Kepatuhan & Manajemen Risiko</div>
                </div>
            </div>
        @endif
    </div>
</div>
