<div class="max-w-4xl mx-auto bg-slate-50 border border-slate-200 rounded-2xl p-8 shadow-sm">
    <div class="text-center mb-8">
        <span class="bg-bauBlue/10 text-bauBlue text-xs font-bold px-3 py-1 rounded-full uppercase">Kalkulator Finansial</span>
        <h2 class="text-3xl font-bold text-bauNavy mt-2">Simulasi Deposito Garuda Prima</h2>
        <p class="text-slate-600 text-sm mt-1">Hitung estimasi imbal hasil investasi deposito berjangka Anda di Bank AU secara akurat.</p>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
        <div class="space-y-6">
            <div>
                <label class="block font-bold text-slate-700 text-sm mb-2">Nominal Deposito (Rp)</label>
                <input type="number" wire:model.live="nominal" step="1000000" class="w-full px-4 py-3 rounded-lg border border-slate-300 font-extrabold text-slate-800 text-lg focus:ring-2 focus:ring-bauBlue">
                <span class="text-xs text-slate-500 mt-1 block">Minimal Rp 5.000.000</span>
            </div>

            <div>
                <label class="block font-bold text-slate-700 text-sm mb-2">Jangka Waktu (Tenor)</label>
                <select wire:model.live="tenor" class="w-full px-4 py-3 rounded-lg border border-slate-300 font-bold text-slate-800 focus:ring-2 focus:ring-bauBlue">
                    <option value="1">1 Bulan (Bunga 4.50% p.a)</option>
                    <option value="3">3 Bulan (Bunga 4.75% p.a)</option>
                    <option value="6">6 Bulan (Bunga 5.00% p.a)</option>
                    <option value="12">12 Bulan (Bunga 5.25% p.a)</option>
                    <option value="24">24 Bulan (Bunga 5.75% p.a)</option>
                </select>
            </div>
        </div>

        <div class="bg-bauNavy text-white p-6 rounded-xl text-center space-y-4 shadow-md">
            <span class="text-xs text-amber-400 font-bold uppercase tracking-wider block">Estimasi Total Saat Jatuh Tempo</span>
            <div class="text-3xl font-black text-amber-400">
                Rp {{ number_format($estimasiHasil, 0, ',', '.') }}
            </div>
            <div class="border-t border-slate-700 pt-3 text-xs text-slate-300 space-y-1">
                <div class="flex justify-between">
                    <span>Pokok Deposito:</span>
                    <span class="font-bold">Rp {{ number_format((float)$nominal, 0, ',', '.') }}</span>
                </div>
                <div class="flex justify-between">
                    <span>Estimasi Bunga Bersih (Setelah Pajak 20%):</span>
                    <span class="font-bold text-emerald-400">+ Rp {{ number_format($estimasiHasil - (float)$nominal, 0, ',', '.') }}</span>
                </div>
            </div>
        </div>
    </div>
</div>
