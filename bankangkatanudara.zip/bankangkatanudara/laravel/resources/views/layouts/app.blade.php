<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PT Bank Angkatan Udara (Persero) Tbk - Official Website</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        bauNavy: '#002244',
                        bauBlue: '#00529B',
                        bauGold: '#D4AF37',
                        bauLight: '#F0F4F8'
                    }
                }
            }
        }
    </script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    @livewireStyles
</head>
<body class="bg-slate-50 text-slate-800 flex flex-col min-h-screen font-sans">

    <!-- Top Security & Info Bar -->
    <div class="bg-bauNavy text-slate-200 text-xs py-2 px-4 border-b border-blue-900">
        <div class="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-2">
            <div class="flex items-center space-x-4">
                <span><i class="fas fa-shield-alt text-amber-400 mr-1"></i> Terdaftar & Diawasi oleh OJK (Otoritas Jasa Keuangan)</span>
                <span class="hidden md:inline">|</span>
                <span class="hidden md:inline"><i class="fas fa-university text-amber-400 mr-1"></i> Peserta Penjaminan LPS</span>
            </div>
            <div class="flex items-center space-x-6">
                <span><i class="fas fa-phone-alt text-amber-400 mr-1"></i> Call Center: <strong>1500-888</strong></span>
                <span><i class="fas fa-envelope text-amber-400 mr-1"></i> layanan@bankau.co.id</span>
            </div>
        </div>
    </div>

    <!-- Navigation Header -->
    <header class="bg-white shadow-md sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 py-3 flex justify-between items-center">
            <!-- Brand Logo -->
            <a href="/" class="flex items-center space-x-3">
                <div class="w-11 h-11 bg-bauNavy text-amber-400 rounded-full flex items-center justify-center text-2xl font-black shadow">
                    <i class="fas fa-plane-departure"></i>
                </div>
                <div>
                    <span class="text-xl font-extrabold text-bauNavy tracking-wider block leading-tight">BANK ANGKATAN UDARA</span>
                    <span class="text-xs text-amber-600 font-semibold tracking-widest block">MENGANGKASA BERSAMA MELAYANI NEGERI</span>
                </div>
            </a>

            <!-- Menu Navigation -->
            <nav class="hidden md:flex items-center space-x-8 font-semibold text-slate-700 text-sm">
                <a href="#beranda" class="hover:text-bauBlue transition">Beranda</a>
                <a href="#tentang" class="hover:text-bauBlue transition">Tentang Kami</a>
                <a href="#layanan" class="hover:text-bauBlue transition">Layanan</a>
                <a href="#kalkulator" class="hover:text-bauBlue transition">Simulasi Deposito</a>
                <a href="#berita" class="hover:text-bauBlue transition">Berita</a>
                <a href="#kontak" class="hover:text-bauBlue transition">Kontak</a>
            </nav>

            <!-- Air-Net Login Button -->
            <div class="flex items-center space-x-3">
                <a href="#airnet" class="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-900 font-bold px-5 py-2.5 rounded-lg shadow-md transition flex items-center space-x-2 text-sm">
                    <i class="fas fa-lock"></i>
                    <span>Air-Net Internet Banking</span>
                </a>
            </div>
        </div>
    </header>

    <!-- Main Content Body -->
    <main class="flex-grow">
        {{ $slot ?? '' }}
        @yield('content')
    </main>

    <!-- Footer -->
    <footer class="bg-bauNavy text-white pt-12 pb-6 border-t-4 border-amber-500">
        <div class="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-8 pb-10 border-b border-slate-700">
            <div>
                <div class="flex items-center space-x-3 mb-4">
                    <div class="w-10 h-10 bg-amber-500 text-bauNavy rounded-full flex items-center justify-center text-xl font-bold">
                        <i class="fas fa-plane-departure"></i>
                    </div>
                    <span class="text-lg font-bold text-white">BANK ANGKATAN UDARA</span>
                </div>
                <p class="text-slate-300 text-sm leading-relaxed mb-4">
                    PT Bank Angkatan Udara (Persero) Tbk berdedikasi tinggi memberikan solusi perbankan terintegrasi dan aman bagi seluruh rakyat Indonesia.
                </p>
            </div>

            <div>
                <h4 class="text-amber-400 font-bold mb-4 text-base">Layanan Perbankan</h4>
                <ul class="space-y-2 text-slate-300 text-sm">
                    <li><a href="#" class="hover:text-amber-400">Tabungan Dirgantara Utama</a></li>
                    <li><a href="#" class="hover:text-amber-400">Deposito Garuda Prima</a></li>
                    <li><a href="#" class="hover:text-amber-400">KPR Air-Home Subsidi</a></li>
                    <li><a href="#" class="hover:text-amber-400">Kredit Usaha Dirgantara</a></li>
                    <li><a href="#" class="hover:text-amber-400">Layanan Bank AU Prioritas</a></li>
                </ul>
            </div>

            <div>
                <h4 class="text-amber-400 font-bold mb-4 text-base">Tautan Cepat</h4>
                <ul class="space-y-2 text-slate-300 text-sm">
                    <li><a href="#tentang" class="hover:text-amber-400">Profil Perusahaan</a></li>
                    <li><a href="#" class="hover:text-amber-400">Laporan Keuangan Tahunan</a></li>
                    <li><a href="#" class="hover:text-amber-400">Tata Kelola Perusahaan (GCG)</a></li>
                    <li><a href="#" class="hover:text-amber-400">Karir & Rekrutmen Militer/Sipil</a></li>
                    <li><a href="#" class="hover:text-amber-400">Syarat & Ketentuan Layanan</a></li>
                </ul>
            </div>

            <div>
                <h4 class="text-amber-400 font-bold mb-4 text-base">Kantor Pusat</h4>
                <p class="text-slate-300 text-sm leading-relaxed mb-2">
                    <i class="fas fa-map-marker-alt text-amber-400 mr-2"></i> Gedung Wisma Dirgantara Utama, Jl. Komando Air Force No. 1, Halim Perdanakusuma, Jakarta Timur.
                </p>
                <p class="text-slate-300 text-sm mb-2"><i class="fas fa-phone text-amber-400 mr-2"></i> (021) 8088-1234</p>
                <p class="text-slate-300 text-sm"><i class="fas fa-headset text-amber-400 mr-2"></i> Call Center 24 Jam: 1500-888</p>
            </div>
        </div>

        <div class="max-w-7xl mx-auto px-4 pt-6 flex flex-col md:flex-row justify-between items-center text-xs text-slate-400">
            <p>&copy; 2026 PT Bank Angkatan Udara (Persero) Tbk. Hak Cipta Dilindungi Undang-Undang.</p>
            <p class="mt-2 md:mt-0 text-amber-400">Simulasi Laboratorium Keamanan Siber & Pengembangan Framework Laravel</p>
        </div>
    </footer>

    @livewireScripts
</body>
</html>
