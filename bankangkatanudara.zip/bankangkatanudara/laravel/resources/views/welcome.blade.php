@extends('layouts.app')

@section('content')
<!-- Hero Section -->
<section id="beranda" class="relative bg-gradient-to-r from-bauNavy via-blue-900 to-bauBlue text-white py-20 px-4 overflow-hidden">
    <div class="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-12 items-center relative z-10">
        <div>
            <span class="inline-block bg-amber-500/20 text-amber-300 text-xs font-bold px-3 py-1.5 rounded-full mb-4 border border-amber-500/40">
                <i class="fas fa-star text-amber-400 mr-1"></i> BANK BUMN TERPERCAYA NASIONAL
            </span>
            <h1 class="text-4xl md:text-5xl font-extrabold leading-tight mb-4">
                Solusi Perbankan Tangguh untuk <span class="text-amber-400">Kemajuan Negeri</span>
            </h1>
            <p class="text-slate-200 text-lg mb-8 leading-relaxed">
                Nikmati kemudahan transaksi finansial, investasi deposito berjangka dengan imbal hasil prima, serta sistem keamanan perbankan siber terkini.
            </p>
            <div class="flex flex-wrap gap-4">
                <a href="#layanan" class="bg-amber-500 hover:bg-amber-600 text-slate-900 font-bold px-6 py-3 rounded-lg shadow-lg transition flex items-center space-x-2">
                    <span>Jelajahi Produk Produk Kami</span>
                    <i class="fas fa-arrow-right"></i>
                </a>
                <a href="#tentang" class="bg-white/10 hover:bg-white/20 text-white font-semibold px-6 py-3 rounded-lg backdrop-blur-sm border border-white/30 transition">
                    Profil Bank AU
                </a>
            </div>
        </div>

        <!-- Banner Card Simulation -->
        <div class="bg-white/10 backdrop-blur-md p-8 rounded-2xl border border-white/20 shadow-2xl text-white">
            <h3 class="text-xl font-bold mb-4 text-amber-400 border-b border-white/20 pb-2">
                <i class="fas fa-shield-alt mr-2"></i> Keunggulan Utama Bank AU
            </h3>
            <ul class="space-y-4 text-sm">
                <li class="flex items-start space-x-3">
                    <i class="fas fa-check-circle text-amber-400 text-lg mt-0.5"></i>
                    <span><strong>Sistem Keamanan Siber Lapis Tiga:</strong> Dilengkapi proteksi enkripsi SSL 256-bit dan otentikasi biometrik.</span>
                </li>
                <li class="flex items-start space-x-3">
                    <i class="fas fa-check-circle text-amber-400 text-lg mt-0.5"></i>
                    <span><strong>Bunga Deposito Kompetitif:</strong> Bunga investasi hingga 5.75% p.a terjamin LPS.</span>
                </li>
                <li class="flex items-start space-x-3">
                    <i class="fas fa-check-circle text-amber-400 text-lg mt-0.5"></i>
                    <span><strong>Air-Net Mobile Banking:</strong> Transaksi real-time gratis biaya transfer antarbank.</span>
                </li>
                <li class="flex items-start space-x-3">
                    <i class="fas fa-check-circle text-amber-400 text-lg mt-0.5"></i>
                    <span><strong>420+ Kantor Cabang & ATM:</strong> Tersebar di seluruh Lanud dan kota besar Indonesia.</span>
                </li>
            </ul>
        </div>
    </div>
</section>

<!-- Statistik Counter -->
<section class="bg-amber-500 text-slate-900 py-8">
    <div class="max-w-7xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
        <div>
            <div class="text-3xl font-extrabold">{{ $profile->total_assets ?? 'Rp 98,6 Triliun' }}</div>
            <div class="text-xs font-bold uppercase tracking-wider mt-1 text-slate-800">Total Aset Kelolaan</div>
        </div>
        <div>
            <div class="text-3xl font-extrabold">{{ $profile->total_branches ?? 420 }}</div>
            <div class="text-xs font-bold uppercase tracking-wider mt-1 text-slate-800">Jaringan Kantor & ATM</div>
        </div>
        <div>
            <div class="text-3xl font-extrabold">{{ $profile->total_clients ?? '3.1 M+' }}</div>
            <div class="text-xs font-bold uppercase tracking-wider mt-1 text-slate-800">Nasabah Aktif</div>
        </div>
        <div>
            <div class="text-3xl font-extrabold">100%</div>
            <div class="text-xs font-bold uppercase tracking-wider mt-1 text-slate-800">Jaminan Penjaminan LPS</div>
        </div>
    </div>
</section>

<!-- Component Livewire Profil Perusahaan -->
<section id="tentang" class="py-16 bg-white">
    <div class="max-w-7xl mx-auto px-4">
        @livewire('company-profile')
    </div>
</section>

<!-- Section Layanan Perbankan -->
<section id="layanan" class="py-16 bg-slate-100">
    <div class="max-w-7xl mx-auto px-4">
        <div class="text-center max-w-3xl mx-auto mb-12">
            <h2 class="text-3xl font-bold text-bauNavy mb-3">Layanan & Produk Unggulan</h2>
            <p class="text-slate-600">Pilihan produk keuangan terbaik yang disesuaikan dengan kebutuhan Anda dan keluarga.</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            @forelse($services as $service)
            <div class="bg-white rounded-xl shadow-md p-6 border border-slate-200 hover:shadow-xl transition">
                <div class="w-12 h-12 bg-blue-100 text-bauBlue rounded-lg flex items-center justify-center text-xl font-bold mb-4">
                    <i class="fas fa-coins"></i>
                </div>
                <span class="text-xs font-bold text-amber-600 uppercase tracking-wide">{{ $service->category }}</span>
                <h3 class="text-xl font-bold text-slate-800 my-2">{{ $service->title }}</h3>
                <p class="text-slate-600 text-sm leading-relaxed mb-4">{{ $service->description }}</p>
                <a href="#" class="text-bauBlue font-bold text-sm hover:underline inline-flex items-center">
                    Ajukan Layanan <i class="fas fa-chevron-right text-xs ml-1"></i>
                </a>
            </div>
            @empty
            <div class="col-span-3 text-center py-8 text-slate-500">Layanan sedang dalam pembaruan.</div>
            @endforelse
        </div>
    </div>
</section>

<!-- Livewire Deposit Calculator -->
<section id="kalkulator" class="py-16 bg-white border-t">
    <div class="max-w-7xl mx-auto px-4">
        @livewire('deposit-calculator')
    </div>
</section>

<!-- Section Berita Terkini -->
<section id="berita" class="py-16 bg-slate-50">
    <div class="max-w-7xl mx-auto px-4">
        <div class="flex justify-between items-end mb-10">
            <div>
                <h2 class="text-3xl font-bold text-bauNavy">Berita & Informasi Terbaru</h2>
                <p class="text-slate-600 text-sm mt-1">Kabar resmi kegiatan dan siaran pers PT Bank Angkatan Udara</p>
            </div>
            <a href="#" class="text-bauBlue font-bold text-sm hover:underline hidden md:block">Lihat Semua Berita &rarr;</a>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            @foreach($news as $item)
            <article class="bg-white rounded-xl shadow border border-slate-200 overflow-hidden flex flex-col">
                <div class="h-44 bg-gradient-to-r from-bauNavy to-bauBlue flex items-center justify-center text-white p-6">
                    <i class="fas fa-newspaper text-5xl text-amber-400 opacity-60"></i>
                </div>
                <div class="p-6 flex-grow flex flex-col justify-between">
                    <div>
                        <div class="flex justify-between text-xs text-slate-500 mb-2">
                            <span class="font-bold text-amber-600">{{ $item->category }}</span>
                            <span>{{ \Carbon\Carbon::parse($item->published_at)->format('d M Y') }}</span>
                        </div>
                        <h3 class="font-bold text-slate-800 text-lg mb-2 line-clamp-2 hover:text-bauBlue">
                            {{ $item->title }}
                        </h3>
                        <p class="text-slate-600 text-sm line-clamp-3 mb-4">{{ $item->summary }}</p>
                    </div>
                    <a href="#" class="text-bauBlue font-bold text-xs hover:underline mt-auto">Baca Selengkapnya &rarr;</a>
                </div>
            </article>
            @endforeach
        </div>
    </div>
</section>

<!-- Section Livewire Contact Form -->
<section id="kontak" class="py-16 bg-bauNavy text-white">
    <div class="max-w-7xl mx-auto px-4">
        @livewire('contact-form')
    </div>
</section>
@endsection
