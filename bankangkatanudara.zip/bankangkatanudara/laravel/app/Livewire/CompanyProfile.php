<?php

namespace App\Livewire;

use Livewire\Component;
use App\Models\CompanyProfile as ProfileModel;

class CompanyProfile extends Component
{
    public $profile;
    public $activeTab = 'tentang';

    public function mount()
    {
        $this->profile = ProfileModel::first();
    }

    public function setTab($tab)
    {
        $this->activeTab = $tab;
    }

    public function render()
    {
        return view('livewire.company-profile');
    }
}
