<?php

namespace App\Livewire;

use Livewire\Component;

class DepositCalculator extends Component
{
    public $nominal = 10000000;
    public $tenor = 12; // bulan
    public $bunga = 5.25; // persen p.a
    public $estimasiHasil = 0;

    public function mount()
    {
        $this->calculate();
    }

    public function updatedNominal() { $this->calculate(); }
    public function updatedTenor() { $this->calculate(); }

    public function calculate()
    {
        $bungaKotor = ($this->nominal * ($this->bunga / 100) * ($this->tenor / 12));
        $pajak = $bungaKotor * 0.20; // Pajak bunga 20%
        $this->estimasiHasil = $this->nominal + ($bungaKotor - $pajak);
    }

    public function render()
    {
        return view('livewire.deposit-calculator');
    }
}
