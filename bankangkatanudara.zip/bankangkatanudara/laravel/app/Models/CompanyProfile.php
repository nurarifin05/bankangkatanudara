<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CompanyProfile extends Model
{
    use HasFactory;

    protected $fillable = [
        'company_name',
        'tagline',
        'about',
        'vision',
        'mission',
        'email',
        'phone',
        'call_center',
        'address',
        'total_assets',
        'total_branches',
        'total_clients',
    ];
}
