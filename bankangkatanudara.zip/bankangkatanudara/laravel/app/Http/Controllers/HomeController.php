<?php

namespace App\Http\Controllers;

use App\Models\CompanyProfile;
use App\Models\Service;
use App\Models\News;

class HomeController extends Controller
{
    public function index()
    {
        $profile = CompanyProfile::first();
        $services = Service::where('is_active', true)->get();
        $news = News::latest()->take(3)->get();

        return view('welcome', compact('profile', 'services', 'news'));
    }
}
